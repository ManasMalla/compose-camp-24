(6)
    
     STEP-1:

        fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val result = firstNumber + secondNumber
    
    println("$firstNumber + $secondNumber = $result");
}


   STEP-2:
       
      fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val result = add(firstNumber, secondNumber)
    val anotherResult = add(firstNumber, thirdNumber)

    println("$firstNumber + $secondNumber = $result");
    println("$firstNumber + $thirdNumber = $anotherResult");
}


fun add(a: Int, b: Int): Int {
    return a + b
}

   STEP-3:

       fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val result = add(firstNumber, secondNumber)
    val anotherResult = add(firstNumber, thirdNumber)
    val subtractionResult = subtract(firstNumber, secondNumber)
    val anotherSubtractionResult = subtract(firstNumber, thirdNumber)

    println("$firstNumber + $secondNumber = $result");
    println("$firstNumber + $thirdNumber = $anotherResult");
    println("$firstNumber - $secondNumber = $subtractionResult");
    println("$firstNumber - $thirdNumber = $anotherSubtractionResult");
}

// Define add() function
fun add(a: Int, b: Int): Int {
    return a + b
}

// Define subtract() function
fun subtract(a: Int, b: Int): Int {
    return a - b
}




