(9)
    
      
      fun spentMoreTimeToday(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    return timeSpentToday > timeSpentYesterday
}

fun main() {
    val timeToday1 = 300
    val timeYesterday1 = 250
    println(spentMoreTimeToday(timeToday1, timeYesterday1)) // Expected output: true

  
    val timeToday2 = 300
    val timeYesterday2 = 300
    println(spentMoreTimeToday(timeToday2, timeYesterday2)) // Expected output: false

    
    val timeToday3 = 200
    val timeYesterday3 = 220
    println(spentMoreTimeToday(timeToday3, timeYesterday3)) // Expected output: false
}





