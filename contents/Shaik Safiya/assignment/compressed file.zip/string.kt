fun main() {
    var discountPercentage: Int = 0
    val item = "Google Chromecast"
    discountPercentage = 20
    val offer = "Sale - Up to $discountPercentage% discount on $item! Hurry up!"
    
    println(offer)
}