fun main() {
    var City = "Ankara"
    var lowTemperature = 27
    var highTemperature = 31
    var chanceOfRain = 82
    displayWeather(City,lowTemperature,highTemperature,chanceOfRain) 
    
    City = "Tokyo"
    lowTemperature = 32
    highTemperature = 36
    chanceOfRain = 10
    displayWeather(City,lowTemperature,highTemperature,chanceOfRain)
    
    City = "Cape Town"
    lowTemperature = 59
    highTemperature = 64
    chanceOfRain = 2
    displayWeather(City,lowTemperature,highTemperature,chanceOfRain)
    
    City = "Guatemala City"
    lowTemperature = 50
    highTemperature = 55
    chanceOfRain = 7
    displayWeather(City,lowTemperature,highTemperature,chanceOfRain)
}
fun displayWeather(City: String,LT: Int,HT: Int ,COR: Int) {
    println("City: $City")
    println("Low temperature: $LT, High temperature: $HT")
    println("Chance of rain: $COR%")
    println()
}