fun main() {
    val totalSteps = 4000
    val caloriesBurned = calculateCaloriesBurned(totalSteps)
    println("Walking $totalSteps steps burns $caloriesBurned calories")
}

fun calculateCaloriesBurned(numberOfSteps: Int): Double {
    val caloriesBurnedForEachStep = 0.04
    val totalCaloriesBurned = numberOfSteps * caloriesBurnedForEachStep
    return totalCaloriesBurned
}
