fun main(){
    var timeSpentToday = 300
    var timeSpentYesterday = 250
    var timeCompare = compareTime(timeSpentToday,timeSpentYesterday)
    display(timeSpentToday,timeSpentYesterday,timeCompare)
    
    timeSpentToday = 300
    timeSpentYesterday = 300
    timeCompare = compareTime(timeSpentToday,timeSpentYesterday)
    display(timeSpentToday,timeSpentYesterday,timeCompare)
    
    timeSpentToday = 200 
    timeSpentYesterday = 220
    timeCompare = compareTime(timeSpentToday,timeSpentYesterday)
    display(timeSpentToday,timeSpentYesterday,timeCompare)
}
fun compareTime(timeSpentToday: Int,timeSpentYesterday: Int): Boolean{
    return timeSpentToday > timeSpentYesterday
}
fun display(timeSpentToday: Int,timeSpentYesterday: Int,timeCompare: Boolean){
    println("timeSpentToday = $timeSpentToday  and timeSpentYesterday = $timeSpentYesterday, the function returns a $timeCompare value.")
}