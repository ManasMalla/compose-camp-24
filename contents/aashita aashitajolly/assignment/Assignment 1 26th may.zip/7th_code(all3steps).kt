# 7th code step 1
fun main() {
    var firstNumber = 10
    var secondNumber = 5
    var result = firstNumber + secondNumber 
    println("$firstNumber + $secondNumber = $result")
}

7th code step 2
fun add(firstNumber:Int, secondNumber:Int):Int{
    return firstNumber+secondNumber
}

7th code step 3
fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val result = subtract(firstNumber, secondNumber)
    val anotherResult = subtract(firstNumber, thirdNumber)

    println("$firstNumber - $secondNumber = $result")
    println("$firstNumber - $thirdNumber = $anotherResult")
}
fun subtract(firstNumber: Int, secondNumber:Int):Int{
    return firstNumber - secondNumber
}