fun main(){
    println("Spent more time on my phone or less?: ${compareTime(300, 250)}")
    println("Spent more time on my phone or less?: ${compareTime(300,300)}")
    println("Spent more time on my phone or less?: ${compareTime(300,220)}")
}
fun compareTime(timeSpentToday: Int, timeSpentYesterday: Int):Boolean{
    return timeSpentToday > timeSpentYesterday
}