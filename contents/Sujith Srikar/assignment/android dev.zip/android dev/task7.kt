fun main() {
    val operatingSystem = "Chrome OS"
    val emailId = "sample@gmail.com"

    println(displayAlertMessage(operatingSystem, emailId))
}

fun displayAlertMessage(os: String, email: String): String {
    return "There is a new sign-in request on $os for your Google Account $email."
}

// Step-2

fun displayAlertMessage(
    os: String = "Unknown OS",
    email: String
): String {
    return "There is a new sign-in request on $os for your Google Account $email."
}