fun main() {
    val message1: String = "Use the val keyword when the value doesn't change."
    val message2: String = "Use the var keyword when the value can change."
    val message3: String = "When you define a function, you define the parameters that can be passed to it."
    val message4: String = "When you call a function, you pass arguments for the parameters."

    println(message1)
    println(message2)
    println(message3)
    println(message4)
}
