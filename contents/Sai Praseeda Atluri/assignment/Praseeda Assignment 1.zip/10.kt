fun main() {
    val result1 = compareScreenTime(timeSpentToday = 300, timeSpentYesterday = 250)
    println("Time spent today is greater than yesterday: $result1")

    val result2 = compareScreenTime(timeSpentToday = 300, timeSpentYesterday = 300)
    println("Time spent today is greater than yesterday: $result2")

    val result3 = compareScreenTime(timeSpentToday = 200, timeSpentYesterday = 220)
    println("Time spent today is greater than yesterday: $result3")
}
fun compareScreenTime(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    return timeSpentToday > timeSpentYesterday
}
