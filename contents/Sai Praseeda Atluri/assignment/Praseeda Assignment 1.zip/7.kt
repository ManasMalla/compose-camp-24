fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val result = add(firstNumber, secondNumber)
    val anotherResult = add(firstNumber, thirdNumber)
    val subtractionResult = subtract(firstNumber, secondNumber)

    println("$firstNumber + $secondNumber = $result")
    println("$firstNumber + $thirdNumber = $anotherResult")
    println("$firstNumber - $secondNumber = $subtractionResult")
}

// Define add() function
fun add(a: Int, b: Int): Int {
    return a + b
}

// Define subtract() function
fun subtract(a: Int, b: Int): Int {
    return a - b
}
