fun main() {
    println(weather("Ankara",27,31,82))
    println(weather("Tokyo",32,36,10))
    println(weather("Cape Town",59,64,2))
    println(weather("Guatemala City",50,55,7))
}

fun weather(city: String, low: Int, high: Int, rain: Int): String {
    return "City: $city\nLow temperature: $low, High temperature: $high\nChance of rain: $rain%\n"
}