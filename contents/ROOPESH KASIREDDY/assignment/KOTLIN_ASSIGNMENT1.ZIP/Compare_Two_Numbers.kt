fun main() {
    var timeSpentToday = 300
    var timeSpentYesterday = 250
    println(greaterTimeSpent(timeSpentToday, timeSpentYesterday))
    
    timeSpentToday = 300
    timeSpentYesterday = 300
    println(greaterTimeSpent(timeSpentToday, timeSpentYesterday))
    
    timeSpentToday = 200
    timeSpentYesterday = 220
    println(greaterTimeSpent(timeSpentToday, timeSpentYesterday))
}

fun greaterTimeSpent(today: Int, yester: Int): Boolean {
    return today>yester
}