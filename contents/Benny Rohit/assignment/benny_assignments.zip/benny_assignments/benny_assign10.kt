fun weatherReport(city: String, lowTemp: Int, highTemp: Int, chanceOfRain: Int) {
    println("City: $city")
    println("Low temperature: $lowTemp, High temperature: $highTemp")
    println("Chance of rain: $chanceOfRain%")
    println()
}

fun main() {
    weatherReport("Ankara", 27, 31, 82)
    weatherReport("Tokyo", 32, 36, 10)
    weatherReport("Cape Town", 59, 64, 2)
    weatherReport("Guatemala City", 50, 55, 7)
}

