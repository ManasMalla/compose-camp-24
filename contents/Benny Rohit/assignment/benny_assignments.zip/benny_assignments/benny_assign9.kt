fun main() {
    val timeSpentToday = 60
    val timeSpentYesterday = 100
    println("Did I spend more time using my phone today: ${compareTimeSpent(timeSpentToday, timeSpentYesterday)}") 
}

fun compareTimeSpent(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    return timeSpentToday > timeSpentYesterday
}
