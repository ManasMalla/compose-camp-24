fun main() { 
    println("New chat message from a friend")
}



New chat message from a friend