fun main() {
    details("Ankara",27,31,82)
  
    details("Tokyo",32,36,10)

    
    details("cape City",59,64,2)
    
    details("Guatemala City",50,55,7)
   
}

fun details(city:String,lowTemperature:Int,highTemperature:Int,rain:Int){
    println("City: $city")
    println("Low temperature: $lowTemperature, High temperature: $highTemperature")
    println("Chance of rain: $rain%")
    println()
}




City: Ankara
Low temperature: 27, High temperature: 31
Chance of rain: 82%

City: Tokyo
Low temperature: 32, High temperature: 36
Chance of rain: 10%

City: cape City
Low temperature: 59, High temperature: 64
Chance of rain: 2%

City: Guatemala City
Low temperature: 50, High temperature: 55
Chance of rain: 7%




