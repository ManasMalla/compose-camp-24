fun main() {
    val discountPercentage: Int = 20
    val item = "Google Chromecast"
    val offer: String = "Sale - Up to $discountPercentage% discount on $item! Hurry up!"
    println(offer)
}