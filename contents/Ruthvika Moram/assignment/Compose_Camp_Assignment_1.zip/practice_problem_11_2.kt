fun main() {
    weatherInfo("Ankara")
}

fun weatherInfo(city: String){
    if(city == "Ankara"){
    println("City: $city")
    println("Low temperature: 27, High temperature: 31")
    println("Chance of rain: 82%")
    println()
	}
    else if (city == "Tokyo"){
    println("City: $city")
    println("Low temperature: 32, High temperature: 36")
    println("Chance of rain: 10%")
    println()
    }
    else if(city == "Cape Town"){
    println("City: $city")
    println("Low temperature: 59, High temperature: 64")
    println("Chance of rain: 2%")
    println()
    }
    else if(city == "Gautemala City"){
    println("City: $city")
    println("Low temperature: 50, High temperature: 55")
    println("Chance of rain: 7%")
    println()
    }
    else
    return println("Invalid City Name entered")
}