fun main() {
    weatherInfo(city = "Ankara", lowTemp = 27, highTemp = 31, Precipitation = 82)
    weatherInfo("Tokyo", 32, 36, 10)
    weatherInfo("Cape Town", 59, 64, 2)
    weatherInfo("Guatemala City", 50, 55, 7)
}

fun weatherInfo(city: String, lowTemp: Int, highTemp: Int, Precipitation: Int){
    println("City: $city")
    println("Low temperature: $lowTemp, High temperature: $highTemp")
    println("Chance of rain: $Precipitation%")
    println()
}