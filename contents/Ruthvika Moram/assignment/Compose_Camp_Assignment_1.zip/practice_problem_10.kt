fun main() {
    var minutesToday = 280
    var minutesYesterday = 320
    var result = screenTimeTracker(minutesToday, minutesYesterday)
    
    if (result == true)
    println("You can reduce your screen time\nJust keep working on Yourself!!")
    else
    println("Congrats!! You've reduced your screen time by ${minutesYesterday - minutesToday} minutes \nKeep Going!!") 
}

fun screenTimeTracker(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    if (timeSpentToday >= timeSpentYesterday)
    return true
    else
    return false
}