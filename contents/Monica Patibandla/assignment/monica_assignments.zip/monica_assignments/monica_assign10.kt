fun printWeatherReport(city: String, lowestTemp: Int, highestTemp: Int, chanceOfRain: Int) {
    println("City: $city")
    println("Low temperature: $lowestTemp, High temperature: $highestTemp")
    println("Chance of rain: $chanceOfRain%")
    println()
}

fun main() {
    printWeatherReport("Ankara", 27, 31, 82)
    printWeatherReport("Tokyo", 32, 36, 10)
    printWeatherReport("Cape Town", 59, 64, 2)
    printWeatherReport("Guatemala City", 50, 55, 7)
}

