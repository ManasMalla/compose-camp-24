fun main() {
    val timeSpentYesterday = 69
    val timeSpentToday = 500000
    println("Have I spent more time today than yesterday: ${compareTimeSpent(timeSpentToday, timeSpentYesterday)}") 
}

fun compareTimeSpent(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    return timeSpentToday > timeSpentYesterday
}
