fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val additionResult = add(firstNumber, secondNumber)
    val subtractionResult = subtract(firstNumber, secondNumber)
    val anotherSubtractionResult = subtract(firstNumber, thirdNumber)

    println("$firstNumber + $secondNumber = $additionResult")
    println("$firstNumber - $secondNumber = $subtractionResult")
    println("$firstNumber - $thirdNumber = $anotherSubtractionResult")
}

fun add(a: Int, b: Int): Int {
    return a + b
}

fun subtract(a: Int, b: Int): Int {
    return a - b
}