fun compareTimeSpent(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    return timeSpentToday > timeSpentYesterday
}

fun main() {
    val timeSpentToday1 = 300
    val timeSpentYesterday1 = 250
    println(compareTimeSpent(timeSpentToday1, timeSpentYesterday1)) // Should print true

    val timeSpentToday2 = 300
    val timeSpentYesterday2 = 300
    println(compareTimeSpent(timeSpentToday2, timeSpentYesterday2)) // Should print false

    val timeSpentToday3 = 200
    val timeSpentYesterday3 = 220
    println(compareTimeSpent(timeSpentToday3, timeSpentYesterday3)) // Should print false
}
