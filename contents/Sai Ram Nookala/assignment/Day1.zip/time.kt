fun main() {
    println("Did I spend more time on my phone today?: ${compareTime(300, 250)}")
    println("Did I spend more time on my phone today?: ${compareTime(300, 300)}")
    println("Did I spend more time on my phone today?: ${compareTime(200, 220)}")
}
fun compareTime(timeSpentToday : Int, timeSpentYesterday : Int):Boolean {
    return timeSpentToday > timeSpentYesterday