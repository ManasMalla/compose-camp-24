part:1

fun main() {
    val firstNumber = 10
    val secondNumber = 5
    var result = firstNumber + secondNumber
    
    println("$firstNumber + $secondNumber = $result")
}

part 2:

fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val result = add(firstNumber, secondNumber)
    val anotherResult = add(firstNumber, thirdNumber)

    println("$firstNumber + $secondNumber = $result")
    println("$firstNumber + $thirdNumber = $anotherResult")
}

fun add(firstNumber : Int , secondNumber : Int) :Int{
    return firstNumber + secondNumber
}

part3:

fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8
    
    val result = add(firstNumber, secondNumber)
    val anotherResult = add(firstNumber, thirdNumber)
    val anotherResult_1 = subtract(firstNumber , secondNumber)

    println("$firstNumber + $secondNumber = $result")
    println("$firstNumber + $thirdNumber = $anotherResult")
    println("$firstNumber - $thirdNumber = $anotherResult_1")
}

fun add(firstNumber : Int , secondNumber : Int) :Int{
    return firstNumber + secondNumber
}

fun subtract(firstNumber : Int , secondNumber : Int) :Int{
    return firstNumber - secondNumber
}

