fun main() {
    val numberOfAdults = 20
    val numberOfKids = 30
    val total = numberOfAdults + numberOfKids
    println("The total party size is: $total")
}
//the code will not produce 50 as output because the variables are strings and that will lead to string concatenation
