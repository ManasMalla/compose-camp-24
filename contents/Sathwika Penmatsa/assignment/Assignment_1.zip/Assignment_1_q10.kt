fun main(){
    weatherDetails("Ankara", 27, 31, 82)
    weatherDetails("Tokyo", 32, 36, 10)
    weatherDetails("Cape Town", 59, 64, 2)
    weatherDetails("Guatemala City", 50, 55, 7)
}

fun weatherDetails(city : String , low_Temp : Int , high_Temp : Int , chance_Of_Rain : Int ){
    println("City:- $city")
    println("Low temperature:- $low_Temp, High temperature:- $high_Temp")
    println("Chance of rain:- $chance_Of_Rain%")
    println()
}