//fix compile error

fun main() { 
    println("New chat message from a friend")
}
/*
 * the main cause of the error is that the string is not enclosed in double  quotes
 * and we used a curly brace instead of a parenthesis at the end
 * this leads to the compilation error
 */