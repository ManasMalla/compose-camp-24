fun main(){
    println("Was the time spent more than yesterday:- ${compareTime(300, 250)}")
    println("Was the time spent more than yesterday:- ${compareTime(300, 300)}")
    println("Was the time spent more than yesterday:- ${compareTime(200, 220)}")
}

fun compareTime(time_Spent_Today: Int, time_Spent_Yesterday: Int): Boolean {
    return time_Spent_Today > time_Spent_Yesterday
}