fun main(){
    val timeSpentToday = 300
    val timeSpentYesterday = 250
    val result = compareScreenTime(timeSpentToday,timeSpentYesterday)
    println("Spent more time on the phone today compared to yesterday: $result")

    fun compareScreenTime(x: Int, y: Int) : Boolean{
        return  x > y
    }
}